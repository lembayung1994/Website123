
document.addEventListener("DOMContentLoaded", function() {
    const chatButton = document.createElement('div');
    chatButton.id = 'chat-button';
    chatButton.innerHTML = 'Chat Kami';

    const chatBox = document.createElement('div');
    chatBox.id = 'chat-box';
    chatBox.innerHTML = `
        <div class="chat-header">Customer Service WayangPlay</div>
        <div class="chat-body">
            <p>Halo! Ada yang bisa kami bantu?</p>
        </div>
        <div class="chat-footer">
            <input type="text" placeholder="Ketik pesan...">
            <button>Kirim</button>
        </div>
    `;

    document.body.appendChild(chatButton);
    document.body.appendChild(chatBox);

    chatButton.addEventListener('click', function() {
        chatBox.classList.toggle('open');
    });
});
